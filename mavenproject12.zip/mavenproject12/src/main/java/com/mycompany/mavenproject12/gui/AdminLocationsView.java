/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject12.gui;

/**
 *
 * @author uuiui
 */


import com.mycompany.mavenproject12.model.Admin;
import com.mycompany.mavenproject12.model.Location;
import com.mycompany.mavenproject12.service.LocationService;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.List;

public class AdminLocationsView extends JFrame {
    
    private Admin admin;
    private DefaultTableModel model;
    private JTable table;
    
    private final Color LINEN = new Color(238, 231, 221);
    private final Color MATCHA = new Color(215, 215, 153);
    private final Color MOSS_GREEN = new Color(146, 148, 51);
    private final Color SELECTION_COLOR = new Color(200, 220, 180);
    
    public AdminLocationsView(Admin admin) {
        this.admin = admin;
        initComponents();
        setTitle("View Locations");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(700, 500);
        setLocationRelativeTo(null);
        loadLocations();
    }
    
    private void initComponents() {
        setLayout(new BorderLayout());
        getContentPane().setBackground(LINEN);
        
        // Top Panel with Back Button
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        topPanel.setBackground(LINEN);
        topPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
        
        JButton backBtn = new JButton("Back to Main Menu");
        backBtn.setBackground(MOSS_GREEN);
        backBtn.setForeground(Color.WHITE);
        backBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        backBtn.setFocusPainted(false);
        backBtn.setBorderPainted(false);
        backBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        backBtn.addActionListener(e -> goBack());
        topPanel.add(backBtn);
        
        add(topPanel, BorderLayout.NORTH);
        
        // Title
        JLabel titleLabel = new JLabel("View Locations");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 22));
        titleLabel.setForeground(MOSS_GREEN);
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        titleLabel.setBorder(new EmptyBorder(10, 0, 15, 0));
        add(titleLabel, BorderLayout.CENTER);
        
        // Table Panel
        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.setBackground(LINEN);
        tablePanel.setBorder(new EmptyBorder(10, 20, 20, 20));
        
        String[] columns = {"ID", "Location Name", "City"};
        model = new DefaultTableModel(columns, 0);
        table = new JTable(model);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setRowHeight(30);
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        table.getTableHeader().setBackground(MATCHA);
        table.setSelectionBackground(SELECTION_COLOR);
        table.setSelectionForeground(Color.BLACK);
        
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createLineBorder(MATCHA, 1));
        tablePanel.add(scrollPane, BorderLayout.CENTER);
        
        add(tablePanel, BorderLayout.CENTER);
    }
    
    private void loadLocations() {
        model.setRowCount(0);
        List<Location> locations = LocationService.getAllLocations();
        
        if (locations == null || locations.isEmpty()) {
            System.out.println("No locations found in database");
            return;
        }
        
        for (Location loc : locations) {
            model.addRow(new Object[]{
                loc.getLocationID(), 
                loc.getName(), 
                loc.getCity()
            });
        }
        
        System.out.println("Loaded " + locations.size() + " locations");
    }
    
    private void goBack() {
        MainMenuFrame mainMenu = new MainMenuFrame(admin);
        mainMenu.setVisible(true);
        this.dispose();
    }
}