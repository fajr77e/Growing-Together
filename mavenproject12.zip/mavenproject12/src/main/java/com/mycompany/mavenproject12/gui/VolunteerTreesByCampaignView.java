/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject12.gui;

/**
 *
 * @author uuiui
 */

import com.mycompany.mavenproject12.model.Volunteer;
import com.mycompany.mavenproject12.model.Tree;
import com.mycompany.mavenproject12.service.TreeService;
import com.mycompany.mavenproject12.service.TreeStatusService;
import com.mycompany.mavenproject12.service.UserService;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.List;

public class VolunteerTreesByCampaignView extends JFrame {
    
    private Volunteer volunteer;
    private int campaignID;
    private String campaignTitle;
    private DefaultTableModel model;
    private JTable treestable;
    private final Color LINEN = new Color(238, 231, 221);
    private final Color MATCHA = new Color(215, 215, 153);
    private final Color MOSS_GREEN = new Color(146, 148, 51);
    
    public VolunteerTreesByCampaignView(Volunteer volunteer, int campaignID, String campaignTitle) {
        this.volunteer = volunteer;
        this.campaignID = campaignID;
        this.campaignTitle = campaignTitle;
        initComponents();
        setTitle("Trees in Campaign: " + campaignTitle);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(900, 500);
        setLocationRelativeTo(null);
        loadTrees();
    }
    
    private void initComponents() {
        setLayout(new BorderLayout());
        getContentPane().setBackground(LINEN);
        
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        topPanel.setBackground(LINEN);
        topPanel.setBorder(new EmptyBorder(10, 10, 5, 10));
        
        JButton backBtn = new JButton("Back to Campaigns");
        backBtn.setBackground(MOSS_GREEN);
        backBtn.setForeground(Color.WHITE);
        backBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        backBtn.setFocusPainted(false);
        backBtn.setBorderPainted(false);
        backBtn.addActionListener(e -> goBack());
        topPanel.add(backBtn);
        
        add(topPanel, BorderLayout.NORTH);
        
        JLabel titleLabel = new JLabel("Trees in Campaign: " + campaignTitle);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titleLabel.setForeground(MOSS_GREEN);
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        titleLabel.setBorder(new EmptyBorder(10, 0, 15, 0));
        add(titleLabel, BorderLayout.CENTER);
        
        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.setBackground(LINEN);
        tablePanel.setBorder(new EmptyBorder(10, 20, 20, 20));
        
        String[] columns = {"Tree ID", "Tree Type", "Quantity", "Planted By", "Location ID", "Health Status"};
        model = new DefaultTableModel(columns, 0);
        treestable = new JTable(model);
        treestable.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        treestable.setRowHeight(30);
        treestable.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        treestable.getTableHeader().setBackground(MATCHA);
        
        JScrollPane scrollPane = new JScrollPane(treestable);
        scrollPane.setBorder(BorderFactory.createLineBorder(MATCHA, 1));
        tablePanel.add(scrollPane, BorderLayout.CENTER);
        
        add(tablePanel, BorderLayout.CENTER);
    }
    

    
    private void loadTrees() {
        model.setRowCount(0);
        List<Tree> trees = TreeService.getTreesByCampaign(campaignID);
        
        for (Tree t : trees) {
            String healthStatus = "Unknown";
            String status = TreeStatusService.getLatestTreeStatus(t.getTreeID());
            if (status != null) healthStatus = status;
            
            // يجب أن يتطابق عدد القيم مع عدد الأعمدة (6)
            model.addRow(new Object[]{
                t.getTreeID(),
                t.getTreeType(),
                t.getQuantity(),
                UserService.getUserByID(t.getPlantedBy()).getFullName(),
                t.getLocationID(),
                healthStatus
            });
        }
        
        if (trees.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No trees have been planted in this campaign yet.");
        }
    }
    
    private void goBack() {
        new VolunteerCampaignsView(volunteer).setVisible(true);
        dispose();
    }
}
