/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject12.service;

/**
 *
 * @author uuiui
 */


import com.mycompany.mavenproject12.model.Location;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class LocationService {
    
    public static List<Location> getAllLocations() {
        List<Location> locations = new ArrayList<>();
        String query = "SELECT * FROM locations";
        
        try (ResultSet rs = DatabaseConnection.executeQuery(query)) {
            while (rs != null && rs.next()) {
                int id = rs.getInt("locationID");
                String name = rs.getString("name");
                String city = rs.getString("city");
                locations.add(new Location(id, name, city));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return locations;
    }
    
    public static Location getLocationByID(int id) {
        String query = "SELECT * FROM locations WHERE locationID = " + id;
        try (ResultSet rs = DatabaseConnection.executeQuery(query)) {
            if (rs != null && rs.next()) {
                String name = rs.getString("name");
                String city = rs.getString("city");
                return new Location(id, name, city);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}
