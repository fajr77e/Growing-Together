/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject12.model;

/**
 *
 * @author uuiui
 */

    import java.util.Date;

public class UserProfile {
    private int profileID;
    private int userID;
    private String bio;
    private String profilePicture;
    private Date joinDate;
    private int points;
   
    public UserProfile(int profileID, int userID, String bio, String profilePicture, Date joinDate, int points) {
        this.profileID = profileID;
        this.userID = userID;
        this.bio = bio;
        this.profilePicture = profilePicture;
        this.joinDate = joinDate;
        this.points = points;
    }
    // Getters and Setters
    public int getProfileID() { return profileID; }
    public void setProfileID(int profileID) { this.profileID = profileID; }
    
    public int getUserID() { return userID; }
    public void setUserID(int userID) { this.userID = userID; }
    
    public String getBio() { return bio; }
    public void setBio(String bio) { this.bio = bio; }
    
    public String getProfilePicture() { return profilePicture; }
    public void setProfilePicture(String profilePicture) { this.profilePicture = profilePicture; }
    
    public Date getJoinDate() { return joinDate; }
    public void setJoinDate(Date joinDate) { this.joinDate = joinDate; }
    
    public int getPoints() { return points; }
    public void setPoints(int points) { this.points = points; }
}
