/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package  com.mycompany.mavenproject12.model;

/**
 *
 * @author uuiui
 */


import java.util.Date;

public class VolunteerRegistration {
    private int registrationID;
    private int campaignID;
    private int volunteerID;
    private Date registeredAt;
    
    // Constructor كامل
    public VolunteerRegistration(int registrationID, int campaignID, int volunteerID, Date registeredAt) {
        this.registrationID = registrationID;
        this.campaignID = campaignID;
        this.volunteerID = volunteerID;
        this.registeredAt = registeredAt;
    }
    
    // Constructor بدون ID
    public VolunteerRegistration(int campaignID, int volunteerID, Date registeredAt) {
        this.campaignID = campaignID;
        this.volunteerID = volunteerID;
        this.registeredAt = registeredAt;
    }
    
    // Getters and Setters
    public int getRegistrationID() { return registrationID; }
    public void setRegistrationID(int registrationID) { this.registrationID = registrationID; }
    
    public int getCampaignID() { return campaignID; }
    public void setCampaignID(int campaignID) { this.campaignID = campaignID; }
    
    public int getVolunteerID() { return volunteerID; }
    public void setVolunteerID(int volunteerID) { this.volunteerID = volunteerID; }
    
    public Date getRegisteredAt() { return registeredAt; }
    public void setRegisteredAt(Date registeredAt) { this.registeredAt = registeredAt; }
    
    @Override
    public String toString() {
        return "Volunteer " + volunteerID + " -> Campaign " + campaignID;
    }
}
