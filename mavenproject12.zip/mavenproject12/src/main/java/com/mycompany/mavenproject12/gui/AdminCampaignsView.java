/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject12.gui;

/**
 *
 * @author uuiui
 */


import com.mycompany.mavenproject12.model.Admin;
import com.mycompany.mavenproject12.model.Campaign;
import com.mycompany.mavenproject12.model.Location;
import com.mycompany.mavenproject12.service.CampaignService;
import com.mycompany.mavenproject12.service.DatabaseConnection;
import com.mycompany.mavenproject12.service.LocationService;
import com.mycompany.mavenproject12.service.UserService;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.io.File;
import java.util.List;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.PrintWriter;
import java.io.IOException;
import java.util.Date;

public class AdminCampaignsView extends JFrame {
    
    private Admin admin;
    private JTable treestable;
    private DefaultTableModel model;
    
    private final Color TEA_ROSE = new Color(235, 180, 178);
    private final Color LINEN = new Color(238, 231, 221);
    private final Color MATCHA = new Color(215, 215, 153);
    private final Color MOSS_GREEN = new Color(146, 148, 51);
    
    public AdminCampaignsView(Admin admin) {
        this.admin = admin;
        initComponents();
        setTitle("View Campaigns");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1100, 600);
        setLocationRelativeTo(null);
        loadCampaigns();
    }
    
    private void initComponents() {
        setLayout(new BorderLayout());
        getContentPane().setBackground(LINEN);
        
        // Top Back Button
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        topPanel.setBackground(LINEN);
        topPanel.setBorder(new EmptyBorder(10, 10, 5, 10));
        
        JButton backBtn = new JButton("Back to Main Menu");
        backBtn.setBackground(MOSS_GREEN);
        backBtn.setForeground(Color.WHITE);
        backBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        backBtn.setFocusPainted(false);
        backBtn.setBorderPainted(false);
        backBtn.addActionListener(e -> goBack());
        topPanel.add(backBtn);
        
        add(topPanel, BorderLayout.NORTH);
        
        // Title
        JLabel titleLabel = new JLabel("View Campaigns");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 22));
        titleLabel.setForeground(MOSS_GREEN);
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        titleLabel.setBorder(new EmptyBorder(10, 0, 15, 0));
        add(titleLabel, BorderLayout.CENTER);
        
        // Table Panel
        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.setBackground(LINEN);
        tablePanel.setBorder(new EmptyBorder(10, 20, 10, 20));
        
        String[] columns = {"ID", "Title", "Date", "Target", "Status", "Supervisor Name", "Location ID"};
        model = new DefaultTableModel(columns, 0);
        treestable = new JTable(model);
        styleTable(treestable);
        
        JScrollPane scrollPane = new JScrollPane(treestable);
        scrollPane.setBorder(BorderFactory.createLineBorder(MATCHA, 1));
        tablePanel.add(scrollPane, BorderLayout.CENTER);
        
        add(tablePanel, BorderLayout.CENTER);
        
        // Action Buttons Panel (under the table)
        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 15));
        actionPanel.setBackground(LINEN);
        actionPanel.setBorder(new EmptyBorder(5, 0, 20, 0));
        JButton exportBtn =createActionButton("Export to CSV");
      

        
        JButton addBtn = createActionButton("Add Campaign");
        JButton updateBtn = createActionButton("Update Status");
        JButton deleteBtn = createActionButton("Delete Campaign");
        JButton viewTreesBtn = createActionButton("View Trees");
        
        addBtn.addActionListener(e -> showAddCampaignDialog());
        updateBtn.addActionListener(e -> updateCampaignStatus());
        deleteBtn.addActionListener(e -> deleteCampaign());
        viewTreesBtn.addActionListener(e -> showTreesByCampaign());
        
        exportBtn.addActionListener(e -> exportToCSV());
     
        actionPanel.add(addBtn);
        actionPanel.add(updateBtn);
        actionPanel.add(deleteBtn);
        actionPanel.add(viewTreesBtn);
        actionPanel.add(exportBtn); 
   
        add(actionPanel, BorderLayout.SOUTH);
    }
    
    private JButton createActionButton(String text) {
        JButton button = new JButton(text);
        button.setBackground(MOSS_GREEN);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Segoe UI", Font.BOLD, 13));
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setPreferredSize(new Dimension(150, 40));
        return button;
    }
    
    private void styleTable(JTable table) {
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setRowHeight(30);
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        table.getTableHeader().setBackground(MATCHA);
        table.setSelectionBackground(Color.BLUE);
        table.setGridColor(new Color(200, 200, 200));
        table.setShowGrid(true);
    }
    
 
    private void loadCampaigns() {
    model.setRowCount(0);
    List<Campaign> campaigns = CampaignService.getAllCampaigns();
    for (Campaign c : campaigns) {
        // جلب اسم المشرف من قاعدة البيانات
        String supervisorName = UserService.getUserByID(c.getSupervisorID()).getFullName();
        
        model.addRow(new Object[]{
            c.getCampaignID(), 
            c.getTitle(), 
            c.getDate(), 
            c.getTarget(), 
            c.getStatus(), 
            supervisorName,  
            c.getLocationID()
        });
    }}
    
 private void showAddCampaignDialog() {
    JDialog dialog = new JDialog(this, "Add New Campaign", true);
    dialog.setLayout(new BorderLayout());
    dialog.setSize(450, 480);
    dialog.setLocationRelativeTo(this);
    dialog.getContentPane().setBackground(LINEN);
    
    JLabel titleLabel = new JLabel("Create New Campaign");
    titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
    titleLabel.setForeground(MOSS_GREEN);
    titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
    titleLabel.setBorder(new EmptyBorder(15, 0, 15, 0));
    dialog.add(titleLabel, BorderLayout.NORTH);
    
    JPanel formPanel = new JPanel(new GridBagLayout());
    formPanel.setBackground(LINEN);
    GridBagConstraints gbc = new GridBagConstraints();
    gbc.insets = new Insets(10, 10, 10, 10);
    gbc.gridx = 0;
    gbc.gridy = 0;
    
    formPanel.add(new JLabel("Title:"), gbc);
    gbc.gridx = 1;
    JTextField titleField = new JTextField(15);
    formPanel.add(titleField, gbc);
    
    gbc.gridx = 0;
    gbc.gridy = 1;
    formPanel.add(new JLabel("Date (YYYY-MM-DD):"), gbc);
    gbc.gridx = 1;
    JTextField dateField = new JTextField(15);
    formPanel.add(dateField, gbc);
    
    gbc.gridx = 0;
    gbc.gridy = 2;
    formPanel.add(new JLabel("Target (trees):"), gbc);
    gbc.gridx = 1;
    JTextField targetField = new JTextField(15);
    formPanel.add(targetField, gbc);
    
    gbc.gridx = 0;
    gbc.gridy = 3;
    formPanel.add(new JLabel("Location:"), gbc);
    gbc.gridx = 1;
    
    JComboBox<String> locationCombo = new JComboBox<>();
    List<Location> locations = LocationService.getAllLocations();
    for (Location loc : locations) {
        locationCombo.addItem(loc.getLocationID() + " - " + loc.getName() + " (" + loc.getCity() + ")");
    }
    locationCombo.setBackground(Color.WHITE);
    locationCombo.setPreferredSize(new Dimension(200, 30));
    formPanel.add(locationCombo, gbc);
    
    // Campaign ID 
    gbc.gridx = 0;
    gbc.gridy = 4;
    formPanel.add(new JLabel("Campaign ID:"), gbc);
    gbc.gridx = 1;
    JTextField campaignIDField = new JTextField(15);
    formPanel.add(campaignIDField, gbc);
    
    dialog.add(formPanel, BorderLayout.CENTER);
    
    JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 15));
    buttonPanel.setBackground(LINEN);
    
    JButton createBtn = new JButton("Create");
    createBtn.setBackground(MOSS_GREEN);
    createBtn.setForeground(Color.WHITE);
    createBtn.addActionListener(e -> {
        try {
           String title = titleField.getText().trim();
String date = dateField.getText().trim();
int target = Integer.parseInt(targetField.getText().trim());
String selectedLocation = (String) locationCombo.getSelectedItem();
int locationID = Integer.parseInt(selectedLocation.split(" - ")[0]);  // 
int campaignID = Integer.parseInt(campaignIDField.getText().trim());

boolean success = CampaignService.createCampaign(
    campaignID, title, java.sql.Date.valueOf(date),
    target, "Active", admin.getUserID(), locationID
);

if (success) {
    JOptionPane.showMessageDialog(dialog, "Campaign created successfully");
    dialog.dispose();
    loadCampaigns();
} else {
    JOptionPane.showMessageDialog(dialog, "Failed to create campaign");
}
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(dialog, "Invalid input! " + ex.getMessage());
            ex.printStackTrace();
        }
    });
    
    JButton cancelBtn = new JButton("Cancel");
    cancelBtn.setBackground(TEA_ROSE);
    cancelBtn.setForeground(MOSS_GREEN);
cancelBtn.addActionListener(e -> dialog.dispose());
    
    buttonPanel.add(createBtn);
    buttonPanel.add(cancelBtn);
    dialog.add(buttonPanel, BorderLayout.SOUTH);
    
    dialog.setVisible(true);
    
}

    private void updateCampaignStatus() {
        int row = treestable.getSelectedRow();
        if (row >= 0) {
            int id = (int) treestable.getValueAt(row, 0);
            String title = (String) treestable.getValueAt(row, 1);
            String[] options = {"Active", "Completed", "Cancelled"};
            String status = (String) JOptionPane.showInputDialog(this, "Select new status for: " + title, "Update Status",
                JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
            if (status != null) {
                boolean success = CampaignService.updateCampaignStatus(id, status);
                JOptionPane.showMessageDialog(this, success ? "Status updated!" : "Update failed!");
                loadCampaigns();
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select a campaign first!");
        }
    }
    
    private void deleteCampaign() {
        String campaignIDStr = JOptionPane.showInputDialog(this, 
            "Enter Campaign ID to delete:",
            "Delete Campaign", JOptionPane.WARNING_MESSAGE);
        
        if (campaignIDStr != null && !campaignIDStr.trim().isEmpty()) {
            try {
                int campaignID = Integer.parseInt(campaignIDStr.trim());
                
                Campaign campaign = CampaignService.getCampaignByID(campaignID);
                if (campaign == null) {
                    JOptionPane.showMessageDialog(this, "Campaign ID " + campaignID + " not found!", "Not Found", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                int confirm = JOptionPane.showConfirmDialog(this, 
                    "Delete campaign:\n" +
                    "ID: " + campaign.getCampaignID() + "\n" +
                    "Title: " + campaign.getTitle() + "\n" +
                    "Target: " + campaign.getTarget() + " trees\n\n" +
                    "This cannot be undone!", 
                    "Confirm Delete", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
                
                if (confirm == JOptionPane.YES_OPTION) {
                    boolean success = CampaignService.deleteCampaign(campaignID);
                    if (success) {
                        JOptionPane.showMessageDialog(this, "Campaign deleted successfully!");
                        loadCampaigns();
                    } else {
                        JOptionPane.showMessageDialog(this, "Failed to delete campaign!");
                    }
                }
                
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Please enter a valid Campaign ID (number)!");
            }
        }
    }
    
    private void showTreesByCampaign() {
        int row = treestable.getSelectedRow();
        if (row >= 0) {
            int campaignID = (int) treestable.getValueAt(row, 0);
            String campaignTitle = (String) treestable.getValueAt(row, 1);
            new AdminTreesByCampaignView(admin, campaignID, campaignTitle).setVisible(true);
            dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Please select a campaign first!");
        }
    }
    
    private void goBack() {
        new MainMenuFrame(admin).setVisible(true);
        dispose();
        
    }
    //  EXPORT METHODS 

private void exportToCSV() {
    JFileChooser fileChooser = new JFileChooser();
    fileChooser.setSelectedFile(new File("campaigns_export.csv"));
    fileChooser.setDialogTitle("Export Campaigns to CSV");
    
    if (fileChooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
        try (java.io.PrintWriter writer = new java.io.PrintWriter(fileChooser.getSelectedFile())) {
            // Write headers
            for (int i = 0; i < treestable.getColumnCount(); i++) {
                writer.print(treestable.getColumnName(i));
                if (i < treestable.getColumnCount() - 1) writer.print(",");
            }
            writer.println();
            
            // Write data rows
            for (int row = 0; row < treestable.getRowCount(); row++) {
                for (int col = 0; col < treestable.getColumnCount(); col++) {
                    Object value = treestable.getValueAt(row, col);
                    writer.print(value != null ? value.toString() : "");
                    if (col < treestable.getColumnCount() - 1) writer.print(",");
                }
                writer.println();
            }
            
            JOptionPane.showMessageDialog(this, "Export successful!\nFile saved to: " + fileChooser.getSelectedFile().getPath());
        } catch (java.io.IOException ex) {
            JOptionPane.showMessageDialog(this, "Export failed: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
}