package com.mycompany.mavenproject12.gui;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author uuiui
 */



import com.mycompany.mavenproject12.service.UserService;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class RegisterForm extends JFrame {

    private JTextField firstNameField;
    private JTextField lastNameField;
    private JTextField emailField;
    private JPasswordField passwordField;
    private JTextField phoneField;
    private JComboBox<String> roleCombo;
    private JButton registerButton;
    private JButton backButton;

    private final Color TEA_ROSE = new Color(235, 180, 178);
    private final Color LINEN = new Color(238, 231, 221);
    private final Color MATCHA = new Color(215, 215, 153);
    private final Color MOSS_GREEN = new Color(146, 148, 51);

    public RegisterForm() {
        initComponents();
        setTitle("Tree Campaign - Register");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 600);
        setLocationRelativeTo(null);
        setResizable(false);
    }

    private void initComponents() {
        JPanel mainPanel = new JPanel(new GridBagLayout());
        mainPanel.setBackground(LINEN);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.gridx = 0;
        gbc.gridwidth = 2;

        // Title
        JLabel titleLabel = new JLabel("Create New Account");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        titleLabel.setForeground(MOSS_GREEN);
        gbc.gridy = 0;
        mainPanel.add(titleLabel, gbc);

        // First Name
        gbc.gridwidth = 1;
        gbc.gridy = 1;
        gbc.gridx = 0;
        JLabel firstNameLabel = new JLabel("First Name:");
        firstNameLabel.setForeground(MOSS_GREEN);
        firstNameLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        mainPanel.add(firstNameLabel, gbc);

        gbc.gridx = 1;
        firstNameField = createStyledTextField();
        mainPanel.add(firstNameField, gbc);

        // Last Name
        gbc.gridy = 2;
        gbc.gridx = 0;
        JLabel lastNameLabel = new JLabel("Last Name:");
        lastNameLabel.setForeground(MOSS_GREEN);
        lastNameLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        mainPanel.add(lastNameLabel, gbc);

        gbc.gridx = 1;
        lastNameField = createStyledTextField();
        mainPanel.add(lastNameField, gbc);

        // Email
        gbc.gridy = 3;
        gbc.gridx = 0;
        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setForeground(MOSS_GREEN);
        emailLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        mainPanel.add(emailLabel, gbc);

        gbc.gridx = 1;
        emailField = createStyledTextField();
        mainPanel.add(emailField, gbc);

        // Password
        gbc.gridy = 4;
        gbc.gridx = 0;
        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setForeground(MOSS_GREEN);
        passwordLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        mainPanel.add(passwordLabel, gbc);

        gbc.gridx = 1;
        passwordField = new JPasswordField(15);
        passwordField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        passwordField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(MATCHA, 1),
                BorderFactory.createEmptyBorder(8, 8, 8, 8)));
        mainPanel.add(passwordField, gbc);

        // Phone
        gbc.gridy = 5;
        gbc.gridx = 0;
        JLabel phoneLabel = new JLabel("Phone:");
        phoneLabel.setForeground(MOSS_GREEN);
        phoneLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        mainPanel.add(phoneLabel, gbc);

        gbc.gridx = 1;
        phoneField = createStyledTextField();
        mainPanel.add(phoneField, gbc);

        // Role
        gbc.gridy = 6;
        gbc.gridx = 0;
        JLabel roleLabel = new JLabel("Role:");
        roleLabel.setForeground(MOSS_GREEN);
        roleLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        mainPanel.add(roleLabel, gbc);

        gbc.gridx = 1;
roleCombo = new JComboBox<>(new String[]{"Volunteer", "Admin"});
        roleCombo.setBackground(Color.WHITE);
        roleCombo.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        mainPanel.add(roleCombo, gbc);

        // Buttons Panel
        gbc.gridy = 7;
        gbc.gridx = 0;
        gbc.gridwidth = 2;
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        buttonPanel.setBackground(LINEN);

        registerButton = new JButton("Register");
        registerButton.setBackground(MOSS_GREEN);
        registerButton.setForeground(Color.WHITE);
        registerButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        registerButton.setFocusPainted(false);
        registerButton.setBorderPainted(false);
        registerButton.setPreferredSize(new Dimension(120, 40));
        registerButton.addActionListener(e -> registerUser());

        backButton = new JButton("Back to Login");
        backButton.setBackground(MOSS_GREEN);
        backButton.setForeground(Color.WHITE);
        backButton.setFont(new Font("Segoe UI", Font.BOLD, 12));
        backButton.setFocusPainted(false);
        backButton.setBorderPainted(false);
        backButton.setPreferredSize(new Dimension(120, 40));
        backButton.addActionListener(e -> goBackToLogin());

        buttonPanel.add(registerButton);
        buttonPanel.add(backButton);
        mainPanel.add(buttonPanel, gbc);

        add(mainPanel);
    }

    private JTextField createStyledTextField() {
        JTextField field = new JTextField(15);
        field.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(MATCHA, 1),
                BorderFactory.createEmptyBorder(8, 8, 8, 8)));
        return field;
    }

    private void registerUser() {
        String firstName = firstNameField.getText().trim();
        String lastName = lastNameField.getText().trim();
        String email = emailField.getText().trim();
        String password = new String(passwordField.getPassword()).trim();
        String phone = phoneField.getText().trim();
        String role = (String) roleCombo.getSelectedItem();

        if (firstName.isEmpty()||lastName.isEmpty()|| email.isEmpty() || password.isEmpty() || phone.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill all fields!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        boolean success = UserService.registerUser(firstName, lastName, email, password, phone, role);
        if (success) {
            JOptionPane.showMessageDialog(this, "Registration successful!\nPlease login.", "Success", JOptionPane.INFORMATION_MESSAGE);
            goBackToLogin();
        } else {
            JOptionPane.showMessageDialog(this, "Registration failed!\nEmail may already exist.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void goBackToLogin() {
        new LoginForm().setVisible(true);
        dispose();
    }
}