/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject12.gui;

/**
 *
 * @author uuiui
 */


import com.mycompany.mavenproject12.model.Volunteer;
import com.mycompany.mavenproject12.model.Campaign;
import com.mycompany.mavenproject12.model.Location;
import com.mycompany.mavenproject12.model.Tree;
import com.mycompany.mavenproject12.service.CampaignService;
import com.mycompany.mavenproject12.service.LocationService;
import com.mycompany.mavenproject12.service.TreeService;
import com.mycompany.mavenproject12.service.TreeStatusService;
import com.mycompany.mavenproject12.service.UserService;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.List;

public class VolunteerTreesView extends JFrame {

    private Volunteer volunteer;
    private DefaultTableModel model;
    private JTable treestable;
    
    private final Color TEA_ROSE = new Color(235, 180, 178);
    private final Color LINEN = new Color(238, 231, 221);
    private final Color MATCHA = new Color(215, 215, 153);
    private final Color MOSS_GREEN = new Color(146, 148, 51);
    
    public VolunteerTreesView(Volunteer volunteer) {
        this.volunteer = volunteer;
        initComponents();
        setTitle("View Trees");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(1100, 600);
        setLocationRelativeTo(null);
        loadTrees();
    }
    
    private void initComponents() {
        setLayout(new BorderLayout());
        getContentPane().setBackground(LINEN);
        
        // Top panel with back button
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        topPanel.setBackground(LINEN);
        topPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
        
        JButton backBtn = new JButton("Back to Main Menu");
        backBtn.setBackground(MOSS_GREEN);
        backBtn.setForeground(Color.WHITE);
        backBtn.setFocusPainted(false);
        backBtn.addActionListener(e -> goBack());
        topPanel.add(backBtn);
        
        add(topPanel, BorderLayout.NORTH);
        
        // Title
        JLabel titleLabel = new JLabel("All Trees");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 22));
        titleLabel.setForeground(MOSS_GREEN);
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        titleLabel.setBorder(new EmptyBorder(10, 0, 15, 0));
        add(titleLabel, BorderLayout.CENTER);
        
        // Table panel
        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.setBackground(LINEN);
        tablePanel.setBorder(new EmptyBorder(10, 20, 10, 20));
        
        String[] columns = {"ID", "Tree Type", "Quantity", "Planted By", "Campaign ID", "Location ID", "Health Status"};
        model = new DefaultTableModel(columns, 0);
        treestable = new JTable(model);
        treestable.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        treestable.setRowHeight(30);
        treestable.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        treestable.getTableHeader().setBackground(MATCHA);
        
        JScrollPane scrollPane = new JScrollPane(treestable);
        scrollPane.setBorder(BorderFactory.createLineBorder(MATCHA, 1));
        tablePanel.add(scrollPane, BorderLayout.CENTER);
        
        add(tablePanel, BorderLayout.CENTER);
        
        // Buttons panel
        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 15));
        actionPanel.setBackground(LINEN);
        
        JButton plantBtn = new JButton("Plant Tree");
        plantBtn.setBackground(MOSS_GREEN);
        plantBtn.setForeground(Color.WHITE);
        plantBtn.addActionListener(e -> showPlantTreeDialog());
        
        JButton updateBtn = new JButton("Update Health Status");
        updateBtn.setBackground(new Color(255, 140, 0));
        updateBtn.setForeground(Color.WHITE);
        updateBtn.addActionListener(e -> updateTreeStatus());
        
        actionPanel.add(plantBtn);
        actionPanel.add(updateBtn);
        
        add(actionPanel, BorderLayout.SOUTH);
    }
private void loadTrees() {
        model.setRowCount(0);
        List<Tree> trees = TreeService.getAllTrees();
        for (Tree t : trees) {
            String healthStatus = TreeStatusService.getLatestTreeStatus(t.getTreeID());
            if (healthStatus == null) healthStatus = "Unknown";
            
            String planterName = UserService.getUserByID(t.getPlantedBy()).getFullName();
            
            model.addRow(new Object[]{
                t.getTreeID(),
                t.getTreeType(),
                t.getQuantity(),
                planterName,
                t.getCampaignID(),
                t.getLocationID(),
                healthStatus
            });
        }
    }
    
    private void showPlantTreeDialog() {
        JDialog dialog = new JDialog(this, "Plant New Tree", true);
        dialog.setLayout(new BorderLayout());
        dialog.setSize(450, 500);
        dialog.setLocationRelativeTo(this);
        dialog.getContentPane().setBackground(LINEN);
        
        JLabel titleLabel = new JLabel("Plant New Tree");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titleLabel.setForeground(MOSS_GREEN);
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        titleLabel.setBorder(new EmptyBorder(15, 0, 15, 0));
        dialog.add(titleLabel, BorderLayout.NORTH);
        
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(LINEN);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.gridx = 0;
        gbc.gridy = 0;
        
        formPanel.add(new JLabel("Tree Type:"), gbc);
        gbc.gridx = 1;
        JTextField typeField = new JTextField(15);
        formPanel.add(typeField, gbc);
        
        gbc.gridx = 0;
        gbc.gridy = 1;
        formPanel.add(new JLabel("Quantity:"), gbc);
        gbc.gridx = 1;
        JTextField quantityField = new JTextField(15);
        formPanel.add(quantityField, gbc);
        
        gbc.gridx = 0;
        gbc.gridy = 2;
        formPanel.add(new JLabel("Campaign ID:"), gbc);
        gbc.gridx = 1;
        JTextField campaignField = new JTextField(15);
        formPanel.add(campaignField, gbc);
        
        gbc.gridx = 0;
        gbc.gridy = 3;
        formPanel.add(new JLabel("Tree ID:"), gbc);
        gbc.gridx = 1;
        JTextField treeIDField = new JTextField(15);
        formPanel.add(treeIDField, gbc);
        
        gbc.gridx = 0;
        gbc.gridy = 4;
        formPanel.add(new JLabel("Location:"), gbc);
        gbc.gridx = 1;
        JComboBox<String> locationCombo = new JComboBox<>();
        List<Location> locations = LocationService.getAllLocations();
        for (Location loc : locations) {
            locationCombo.addItem(loc.getLocationID() + " - " + loc.getName());
        }
        formPanel.add(locationCombo, gbc);
        
        dialog.add(formPanel, BorderLayout.CENTER);
        
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 15));
        buttonPanel.setBackground(LINEN);
        
        JButton plantBtn = new JButton("Plant");
        plantBtn.setBackground(MOSS_GREEN);
        plantBtn.setForeground(Color.WHITE);
        plantBtn.addActionListener(e -> {
            try {
                int treeID = Integer.parseInt(treeIDField.getText().trim());
                String treeType = typeField.getText().trim();
                int quantity = Integer.parseInt(quantityField.getText().trim());
                int campaignID = Integer.parseInt(campaignField.getText().trim());
                String selectedLocation = (String) locationCombo.getSelectedItem();
                int locationID = Integer.parseInt(selectedLocation.split(" - ")[0]);
                
                if (treeType.isEmpty()) {
                    JOptionPane.showMessageDialog(dialog, "Please enter tree type!");
                    return;
                }
                
                Campaign campaign = CampaignService.getCampaignByID(campaignID);
if (campaign == null) {
                    JOptionPane.showMessageDialog(dialog, "Campaign ID does not exist!");
                    return;
                }
                
                boolean success = TreeService.plantTree(treeID, treeType, quantity, volunteer.getUserID(), campaignID, locationID);
                if (success) {
                    JOptionPane.showMessageDialog(dialog, "Tree planted successfully!");
                    dialog.dispose();
                    loadTrees();
                } else {
                    JOptionPane.showMessageDialog(dialog, "Failed to plant tree!");
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(dialog, "Please enter valid numbers!");
            }
        });
        
        JButton cancelBtn = new JButton("Cancel");
        cancelBtn.setBackground(TEA_ROSE);
        cancelBtn.setForeground(MOSS_GREEN);
        cancelBtn.addActionListener(e -> dialog.dispose());
        
        buttonPanel.add(plantBtn);
        buttonPanel.add(cancelBtn);
        dialog.add(buttonPanel, BorderLayout.SOUTH);
        
        dialog.setVisible(true);
    }
    
    private void updateTreeStatus() {
        int row = treestable.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Please select a tree first!");
            return;
        }
        
        int treeID = (int) treestable.getValueAt(row, 0);
        String treeType = (String) treestable.getValueAt(row, 1);
        String[] options = {"Healthy", "Not Watered", "Dead"};
        String status = (String) JOptionPane.showInputDialog(this, "Select health status for: " + treeType,
                "Update Status", JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
        if (status != null) {
            boolean success = TreeStatusService.reportTreeStatus(treeID, volunteer.getUserID(), status);
            JOptionPane.showMessageDialog(this, success ? "Tree status updated!" : "Update failed!");
            loadTrees();
        }
    }
    
    private void goBack() {
        new MainMenuFrame(volunteer).setVisible(true);
        dispose();
    }
}