/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject12.gui;

/**
 *
 * @author uuiui
 */


import com.mycompany.mavenproject12.model.Admin;
import com.mycompany.mavenproject12.model.Campaign;
import com.mycompany.mavenproject12.model.Location;
import com.mycompany.mavenproject12.model.Tree;
import com.mycompany.mavenproject12.service.CampaignService;
import com.mycompany.mavenproject12.service.LocationService;
import com.mycompany.mavenproject12.service.TreeService;
import com.mycompany.mavenproject12.service.TreeStatusService;
import com.mycompany.mavenproject12.service.UserService;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.List;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintWriter;
import java.io.IOException;

public class AdminTreesView extends JFrame {
    
    private Admin admin;
    
    private JTable treestable;
    private DefaultTableModel model;
    
    private final Color TEA_ROSE = new Color(235, 180, 178);
    private final Color LINEN = new Color(238, 231, 221);
    private final Color MATCHA = new Color(215, 215, 153);
    private final Color MOSS_GREEN = new Color(146, 148, 51);
    
    public AdminTreesView(Admin admin) {
        this.admin = admin;
        initComponents();
        setTitle("View Trees");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1100, 600);
        setLocationRelativeTo(null);
        loadTrees();
    }
    
    private void initComponents() {
        setLayout(new BorderLayout());
        getContentPane().setBackground(LINEN);
        
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        topPanel.setBackground(LINEN);
        topPanel.setBorder(new EmptyBorder(10, 10, 5, 10));
        
        JButton backBtn = new JButton("Back to Main Menu");
        backBtn.setBackground(MOSS_GREEN);
        backBtn.setForeground(Color.WHITE);
        backBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        backBtn.setFocusPainted(false);
        backBtn.setBorderPainted(false);
        backBtn.addActionListener(e -> goBack());
        topPanel.add(backBtn);
        
        add(topPanel, BorderLayout.NORTH);
        
        JLabel titleLabel = new JLabel("View Trees");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 22));
        titleLabel.setForeground(MOSS_GREEN);
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        titleLabel.setBorder(new EmptyBorder(10, 0, 15, 0));
        add(titleLabel, BorderLayout.CENTER);
        
        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.setBackground(LINEN);
        tablePanel.setBorder(new EmptyBorder(10, 20, 10, 20));
        
        String[] columns = {"ID", "Tree Type", "Quantity", "Planted By Name", "Campaign ID", "Location ID", "Health Status"};
        model = new DefaultTableModel(columns, 0);
        treestable = new JTable(model);
        styleTable(treestable);
        
        JScrollPane scrollPane = new JScrollPane(treestable);
        scrollPane.setBorder(BorderFactory.createLineBorder(MATCHA, 1));
        tablePanel.add(scrollPane, BorderLayout.CENTER);
        
        add(tablePanel, BorderLayout.CENTER);
        
        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 15));
        actionPanel.setBackground(LINEN);
        actionPanel.setBorder(new EmptyBorder(5, 0, 20, 0));
        
        JButton addBtn = createActionButton("Add Tree");
        JButton updateBtn = createActionButton("Update Health Status");
        JButton deleteBtn = createActionButton("Delete Tree");
        JButton exportBtn = createActionButton("Export to CSV");      
        JButton importBtn = createActionButton("Import from CSV"); 
        addBtn.addActionListener(e -> showAddTreeDialog());
        updateBtn.addActionListener(e -> updateTreeStatus());
        deleteBtn.addActionListener(e -> deleteTree());
         exportBtn.addActionListener(e -> exportToCSV());             
         importBtn.addActionListener(e -> importFromCSV()); 
        actionPanel.add(addBtn);
        actionPanel.add(updateBtn);
        actionPanel.add(deleteBtn);
        actionPanel.add(exportBtn);      
        actionPanel.add(importBtn);      

        add(actionPanel, BorderLayout.SOUTH);
    }
    
    private JButton createActionButton(String text) {
        JButton button = new JButton(text);
        button.setBackground(MOSS_GREEN);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Segoe UI", Font.BOLD, 13));
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setPreferredSize(new Dimension(160, 40));
        return button;
    }
    
    private void styleTable(JTable table) {
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setRowHeight(30);
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        table.getTableHeader().setBackground(MATCHA);
        table.setSelectionBackground(Color.blue);
        table.setGridColor(new Color(200, 200, 200));
        table.setShowGrid(true);
    }
    
  private void loadTrees() {
    model.setRowCount(0);
    List<Tree> trees = TreeService.getAllTrees();
    for (Tree t : trees) {
        String healthStatus = TreeStatusService.getLatestTreeStatus(t.getTreeID());
       model.addRow(new Object[]{
            t.getTreeID(),
            t.getTreeType(),
            t.getQuantity(),
            UserService.getUserByID(t.getPlantedBy()).getFullName(),
            t.getCampaignID(),
            t.getLocationID(),
            healthStatus != null ? healthStatus : "Unknown"
        });
    }
}
 
    
    private void showAddTreeDialog() {
    JDialog dialog = new JDialog(this, "Add New Tree", true);
    dialog.setLayout(new BorderLayout());
    dialog.setSize(450, 500);
    dialog.setLocationRelativeTo(this);
    dialog.getContentPane().setBackground(LINEN);

    JLabel titleLabel = new JLabel("Add New Tree");
    titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
    titleLabel.setForeground(MOSS_GREEN);
    titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
    titleLabel.setBorder(new EmptyBorder(15, 0, 15, 0));
    dialog.add(titleLabel, BorderLayout.NORTH);

    JPanel formPanel = new JPanel(new GridBagLayout());
    formPanel.setBackground(LINEN);
    GridBagConstraints gbc = new GridBagConstraints();
    gbc.insets = new Insets(10, 10, 10, 10);
    gbc.gridx = 0;
    gbc.gridy = 0;

    // Tree Type
    formPanel.add(new JLabel("Tree Type:"), gbc);
    gbc.gridx = 1;
    JTextField typeField = new JTextField(15);
    formPanel.add(typeField, gbc);

    // Quantity
    gbc.gridx = 0;
    gbc.gridy = 1;
    formPanel.add(new JLabel("Quantity:"), gbc);
    gbc.gridx = 1;
    JTextField quantityField = new JTextField(15);
    formPanel.add(quantityField, gbc);

    // Campaign ID
    gbc.gridx = 0;
    gbc.gridy = 2;
    formPanel.add(new JLabel("Campaign ID:"), gbc);
    gbc.gridx = 1;
    JTextField campaignField = new JTextField(15);
    formPanel.add(campaignField, gbc);

    // Tree ID (مهم)
    gbc.gridx = 0;
    gbc.gridy = 3;
    formPanel.add(new JLabel("Tree ID:"), gbc);
    gbc.gridx = 1;
    JTextField treeIDField = new JTextField(15);
    formPanel.add(treeIDField, gbc);

    // Location
    gbc.gridx = 0;
    gbc.gridy = 4;
    formPanel.add(new JLabel("Location:"), gbc);
    gbc.gridx = 1;
    JComboBox<String> locationCombo = new JComboBox<>();
    List<Location> locations = LocationService.getAllLocations();
    for (Location loc : locations) {
        locationCombo.addItem(loc.getLocationID() + " - " + loc.getName());
    }
    formPanel.add(locationCombo, gbc);

    dialog.add(formPanel, BorderLayout.CENTER);

    JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 15));
    buttonPanel.setBackground(LINEN);

    JButton addBtn = new JButton("Add");
    addBtn.setBackground(MOSS_GREEN);
    addBtn.setForeground(Color.WHITE);
    addBtn.addActionListener(e -> {
        try {
            int treeID = Integer.parseInt(treeIDField.getText().trim());
            String treeType = typeField.getText().trim();
            int quantity = Integer.parseInt(quantityField.getText().trim());
            int campaignID = Integer.parseInt(campaignField.getText().trim());
            String selectedLocation = (String) locationCombo.getSelectedItem();
            int locationID = Integer.parseInt(selectedLocation.split(" - ")[0]);

            if (treeType.isEmpty()) {
                JOptionPane.showMessageDialog(dialog, "Please enter tree type!");
                return;
            }

            // التأكد من وجود الحملة
            Campaign campaign = CampaignService.getCampaignByID(campaignID);
            if (campaign == null) {
                JOptionPane.showMessageDialog(dialog, "Campaign ID not found!");
                return;
            }

            boolean success = TreeService.plantTree(treeID, treeType, quantity, admin.getUserID(), campaignID, locationID);
            if (success) {
                JOptionPane.showMessageDialog(dialog, "Tree added successfully!");
                dialog.dispose();
                loadTrees(); // تحديث الجدول
            } else {
                JOptionPane.showMessageDialog(dialog, "Failed to add tree!");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(dialog, "Please enter valid numbers for IDs and quantity!");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(dialog, "Error: " + ex.getMessage());
        }
    });

    JButton cancelBtn = new JButton("Cancel");
    cancelBtn.setBackground(TEA_ROSE);
    cancelBtn.setForeground(Color.WHITE);
    cancelBtn.
addActionListener(e -> dialog.dispose());

    buttonPanel.add(addBtn);
    buttonPanel.add(cancelBtn);
    dialog.add(buttonPanel, BorderLayout.SOUTH);

    dialog.setVisible(true);
}
    
    private void updateTreeStatus() {
    int selectedRow = treestable.getSelectedRow();
    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(this, "Please select a tree first.");
        return;
    }

    int treeID = (int) treestable.getValueAt(selectedRow, 0);
    String treeType = (String) treestable.getValueAt(selectedRow, 1);

    String[] statuses = {"Healthy", "Not Watered", "Dead"};
    String newStatus = (String) JOptionPane.showInputDialog(
        this,
        "Select health status for " + treeType + ":",
        "Update Tree Status",
        JOptionPane.QUESTION_MESSAGE,
        null,
        statuses,
        statuses[0]
    );

    if (newStatus != null) {
        boolean success = TreeStatusService.reportTreeStatus(treeID, admin.getUserID(), newStatus);
        if (success) {
            JOptionPane.showMessageDialog(this, "Tree status updated successfully.");
            loadTrees(); // تحديث الجدول
        } else {
            JOptionPane.showMessageDialog(this, "Update failed. Check if tree ID exists.");
        }
    }
}
   
    
    private void deleteTree() {
        JPanel panel = new JPanel(new GridLayout(2, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        panel.add(new JLabel("Campaign ID:"));
        JTextField campaignField = new JTextField();
        panel.add(campaignField);
        panel.add(new JLabel("Tree ID:"));
        JTextField treeIDField = new JTextField();
        panel.add(treeIDField);
        
        int result = JOptionPane.showConfirmDialog(this, panel, "Enter Tree Details to Delete", 
            JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        
        if (result == JOptionPane.OK_OPTION) {
            try {
                int campaignID = Integer.parseInt(campaignField.getText().trim());
                int treeID = Integer.parseInt(treeIDField.getText().trim());
                
                List<Tree> trees = TreeService.getAllTrees();
                boolean treeFound = false;
                Tree foundTree = null;
                
                for (Tree t : trees) {
                    if (t.getTreeID() == treeID && t.getCampaignID() == campaignID) {
                        treeFound = true;
                        foundTree = t;
                        break;
                    }
                }
                
                if (!treeFound) {
                    JOptionPane.showMessageDialog(this, 
                        "Tree ID " + treeID + " not found in Campaign ID " + campaignID + "!", 
                        "Tree Not Found", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                int confirm = JOptionPane.showConfirmDialog(this, 
                    "Delete tree:\n" +
                    "Tree ID: " + foundTree.getTreeID() + "\n" +
                    "Tree Type: " + foundTree.getTreeType() + "\n" +
                    "Quantity: " + foundTree.getQuantity() + "\n" +
                    "Campaign ID: " + foundTree.getCampaignID() + "\n\n" +
                    "This cannot be undone!", 
                    "Confirm Delete", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
                
                if (confirm == JOptionPane.YES_OPTION) {
                    boolean success = TreeService.deleteTree(treeID);
                    if (success) {
                        JOptionPane.showMessageDialog(this, "Tree deleted successfully!");
                        loadTrees();
                    } else {
                        JOptionPane.showMessageDialog(this, "Failed to delete tree!");
                    }
                }
                
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Please enter valid numbers for Campaign ID and Tree ID!");
            }
        }
    }
    
    private void goBack() {
        new MainMenuFrame(admin).setVisible(true);
        dispose();
    }
    //  EXPORT/IMPORT METHODS 

private void exportToCSV() {
    JFileChooser fileChooser = new JFileChooser();
    fileChooser.setSelectedFile(new File("trees_export.csv"));
    fileChooser.setDialogTitle("Export Trees to CSV");
    
    if (fileChooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
        try (java.io.PrintWriter writer = new java.io.PrintWriter(fileChooser.getSelectedFile())) {
            for (int i = 0; i < treestable.getColumnCount(); i++) {
                writer.print(treestable.getColumnName(i));
                if (i < treestable.getColumnCount() - 1) writer.print(",");
            }
            writer.println();
            
            for (int row = 0; row < treestable.getRowCount(); row++) {
                for (int col = 0; col < treestable.getColumnCount(); col++) {
                    Object value = treestable.getValueAt(row, col);
                    writer.print(value != null ? value.toString() : "");
                    if (col < treestable.getColumnCount() - 1) writer.print(",");
                }
                writer.println();
            }
            
            JOptionPane.showMessageDialog(this, "Export successful!");
        } catch (java.io.IOException ex) {
            JOptionPane.showMessageDialog(this, "Export failed: " + ex.getMessage());
        }
    }
}

private void importFromCSV() {
    JFileChooser fileChooser = new JFileChooser();
    fileChooser.setDialogTitle("Import Trees from CSV");
    fileChooser.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("CSV Files", "csv"));
    
    if (fileChooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
        try (BufferedReader reader = new BufferedReader(new FileReader(fileChooser.getSelectedFile()))) {
            String line;
            int importedCount = 0;
            int errorCount = 0;
            
            // تخطي سطر الرأس (headers)
            reader.readLine();
            
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                if (data.length >= 7) {  // نتوقع 7 أعمدة: treeID, treeType, quantity, plantedBy, campaignID, locationID, healthStatus (اختياري)
                    try {
                        int treeID = Integer.parseInt(data[0].trim());
                        String treeType = data[1].trim();
                        int quantity = Integer.parseInt(data[2].trim());
                        int plantedBy = Integer.parseInt(data[3].trim());   // معرف المتطوع أو الأدمن
                        int campaignID = Integer.parseInt(data[4].trim());
                        int locationID = Integer.parseInt(data[5].trim());
                        
                        // استخدم الدالة الصحيحة (تدعم ID يدوي)
                        boolean success = TreeService.plantTree(treeID, treeType, quantity, plantedBy, campaignID, locationID);
                        if (success) {
                            importedCount++;
                        } else {
                            errorCount++;
                        }
                    } catch (NumberFormatException ex) {
                        errorCount++;
                        System.err.println("Invalid number format in line: " + line);
                    } catch (Exception ex) {
                        errorCount++;
                        System.err.println("Error inserting tree: " + ex.getMessage());
                    }
                } else {
                    errorCount++;
                    System.err.println("Skipping invalid line (not enough columns): " + line);
                }
            }
            
            JOptionPane.showMessageDialog(this, 
                "Import completed!\nImported: " + importedCount + "\nErrors: " + errorCount,
                "Import Results", JOptionPane.INFORMATION_MESSAGE);
            
            if (importedCount > 0) {
                loadTrees();  // تحديث الجدول
            }
            
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Import failed: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }
}
 
}

