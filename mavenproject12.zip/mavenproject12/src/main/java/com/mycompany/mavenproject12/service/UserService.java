/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject12.service;

/**
 *
 * @author uuiui
 */

import com.mycompany.mavenproject12.model.User;
import com.mycompany.mavenproject12.model.Admin;
import com.mycompany.mavenproject12.model.Volunteer;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UserService {
    
    // Register new user
   public static boolean registerUser(String firstName, String lastName, String email, String password, String phone, String role) {
    if (isEmailExists(email)) {
        System.err.println("Email already exists");
        return false;
    }
    
    // الحصول على أكبر userID موجود + 1
    int nextId = getNextUserId();
    
    String query = String.format(
        "INSERT INTO users (userID, firstName, lastName, email, password, phone, role) " +
        "VALUES (%d, '%s', '%s', '%s', '%s', '%s', '%s')",
        nextId, firstName, lastName, email, password, phone, role
    );
    int result = DatabaseConnection.executeUpdate(query);
    return result > 0;
}

// دالة مساعدة لجلب أكبر userID + 1
private static int getNextUserId() {
    String query = "SELECT IFNULL(MAX(userID), 1009) + 1 AS nextId FROM users";
    try (ResultSet rs = DatabaseConnection.executeQuery(query)) {
        if (rs != null && rs.next()) {
            return rs.getInt("nextId");
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return 1010; // القيمة الافتراضية إذا فشل الاستعلام
}
    
    // User login
    public static User login(String email, String password) {
        String query = String.format(
            "SELECT * FROM users WHERE email = '%s' AND password = '%s'",
            email, password
        );
        
        try (ResultSet rs = DatabaseConnection.executeQuery(query)) {
            if (rs != null && rs.next()) {
                int userID = rs.getInt("userID");
                String firstName = rs.getString("firstName");
                String lastName = rs.getString("lastName");
                String phone = rs.getString("phone");
                String role = rs.getString("role");
                
                if (role.equals("Admin")) {
                    return new Admin(userID, firstName, lastName, email, password, phone);
                } else {
                    return new Volunteer(userID, firstName, lastName, email, password, phone);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        System.err.println("Invalid email or password");
        return null;
    }
    
    // Check if email exists
    public static boolean isEmailExists(String email) {
        String query = String.format("SELECT * FROM users WHERE email = '%s'", email);
        
        try (ResultSet rs = DatabaseConnection.executeQuery(query)) {
            return rs != null && rs.next();
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    // Get all users
    public static List<User> getAllUsers() {
        List<User> users = new ArrayList<>();
        String query = "SELECT * FROM users";
        
        try (ResultSet rs = DatabaseConnection.executeQuery(query)) {
            while (rs != null && rs.next()) {
                int userID = rs.getInt("userID");
                String firstName = rs.getString("firstName");
                String lastName = rs.getString("lastName");
                String email = rs.getString("email");
                String password = rs.getString("password");
                String phone = rs.getString("phone");
                String role = rs.getString("role");
                
                if (role.equals("Admin")) {
                    users.add(new Admin(userID, firstName, lastName, email, password, phone));
                } else {
                    users.add(new Volunteer(userID, firstName, lastName, email, password, phone));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return users;
    }
    
    // Get user by ID
    public static User getUserByID(int userID) {
        String query = String.format("SELECT * FROM users WHERE userID = %d", userID);
        
        try (ResultSet rs = DatabaseConnection.executeQuery(query)) {
            if (rs != null && rs.next()) {
                String firstName = rs.getString("firstName");
                String lastName = rs.getString("lastName");
                String email = rs.getString("email");
String password = rs.getString("password");
                String phone = rs.getString("phone");
                String role = rs.getString("role");
                
                if (role.equals("Admin")) {
                    return new Admin(userID, firstName, lastName, email, password, phone);
                } else {
                    return new Volunteer(userID, firstName, lastName, email, password, phone);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return null;
    }
    
    // Update user data
    public static boolean updateUser(int userID, String firstName, String lastName, String phone) {
        String query = String.format(
            "UPDATE users SET firstName = '%s', lastName = '%s', phone = '%s' WHERE userID = %d",
            firstName, lastName, phone, userID
        );
        
        int result = DatabaseConnection.executeUpdate(query);
        return result > 0;
    }
    
    // Delete user
    public static boolean deleteUser(int userID) {
        String query = String.format("DELETE FROM users WHERE userID = %d", userID);
        int result = DatabaseConnection.executeUpdate(query);
        return result > 0;
    }
    
    // Get user profile points
    public static int getUserPoints(int userID) {
        String query = String.format("SELECT points FROM user_profiles WHERE userID = %d", userID);
        try (ResultSet rs = DatabaseConnection.executeQuery(query)) {
            if (rs != null && rs.next()) {
                return rs.getInt("points");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }
    
    // Get user skills
    public static List<String> getUserSkills(int userID) {
        List<String> skills = new ArrayList<>();
        String query = String.format("SELECT skill FROM volunteer_skills WHERE userID = %d", userID);
        try (ResultSet rs = DatabaseConnection.executeQuery(query)) {
            while (rs != null && rs.next()) {
                skills.add(rs.getString("skill"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return skills;
    }
}
