/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject12.service;

/**
 *
 * @author uuiui
 */


import com.mycompany.mavenproject12.model.Campaign;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class CampaignService {
    
    // Create new campaign
    public static boolean createCampaign(String title, Date date, int target, String status, int supervisorID, int locationID) {
        String query = String.format(
            "INSERT INTO campaigns (title, date, target, status, supervisorID, locationID) VALUES ('%s', '%s', %d, '%s', %d, %d)",
            title, new java.sql.Date(date.getTime()), target, status, supervisorID, locationID
        );
        
        int result = DatabaseConnection.executeUpdate(query);
        return result > 0;
    }
    
    // Get all campaigns
    public static List<Campaign> getAllCampaigns() {
        List<Campaign> campaigns = new ArrayList<>();
        String query = "SELECT * FROM campaigns";
        
        try (ResultSet rs = DatabaseConnection.executeQuery(query)) {
            while (rs != null && rs.next()) {
                int campaignID = rs.getInt("campaignID");
                String title = rs.getString("title");
                Date date = rs.getDate("date");
                int target = rs.getInt("target");
                String status = rs.getString("status");
                int supervisorID = rs.getInt("supervisorID");
                int locationID = rs.getInt("locationID");
                
                campaigns.add(new Campaign(campaignID, title, date, target, status, supervisorID, locationID));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return campaigns;
    }
    
    // Get campaign by ID
    public static Campaign getCampaignByID(int campaignID) {
        String query = String.format("SELECT * FROM campaigns WHERE campaignID = %d", campaignID);
        
        try (ResultSet rs = DatabaseConnection.executeQuery(query)) {
            if (rs != null && rs.next()) {
                String title = rs.getString("title");
                Date date = rs.getDate("date");
                int target = rs.getInt("target");
                String status = rs.getString("status");
                int supervisorID = rs.getInt("supervisorID");
                int locationID = rs.getInt("locationID");
                
                return new Campaign(campaignID, title, date, target, status, supervisorID, locationID);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return null;
    }
    
    // Get active campaigns
    public static List<Campaign> getActiveCampaigns() {
        List<Campaign> campaigns = new ArrayList<>();
        String query = "SELECT * FROM campaigns WHERE status = 'Active'";
        
        try (ResultSet rs = DatabaseConnection.executeQuery(query)) {
            while (rs != null && rs.next()) {
                int campaignID = rs.getInt("campaignID");
                String title = rs.getString("title");
                Date date = rs.getDate("date");
                int target = rs.getInt("target");
                String status = rs.getString("status");
                int supervisorID = rs.getInt("supervisorID");
                int locationID = rs.getInt("locationID");
                
                campaigns.add(new Campaign(campaignID, title, date, target, status, supervisorID, locationID));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return campaigns;
    }
    
    // Update campaign status
    public static boolean updateCampaignStatus(int campaignID, String status) {
        String query = String.format(
            "UPDATE campaigns SET status = '%s' WHERE campaignID = %d",
            status, campaignID
        );
        
        int result = DatabaseConnection.executeUpdate(query);
        return result > 0;
    }
    
    // Update campaign target
    public static boolean updateCampaignTarget(int campaignID, int target) {
        String query = String.format(
            "UPDATE campaigns SET target = %d WHERE campaignID = %d",
            target, campaignID
        );
        
        int result = DatabaseConnection.executeUpdate(query);
        return result > 0;
    }
    
    // Delete campaign
    public static boolean deleteCampaign(int campaignID) {
        String query = String.format("DELETE FROM campaigns WHERE campaignID = %d", campaignID);
        int result = DatabaseConnection.executeUpdate(query);
        return result > 0;
    }
    
    // Get campaigns by supervisor
    public static List<Campaign> getCampaignsBySupervisor(int supervisorID) {
        List<Campaign> campaigns = new ArrayList<>();
        String query = String.format("SELECT * FROM campaigns WHERE supervisorID = %d", supervisorID);
        
        try (ResultSet rs = DatabaseConnection.executeQuery(query)) {
            while (rs != null && rs.next()) {
                int campaignID = rs.getInt("campaignID");
                String title = rs.getString("title");
                Date date = rs.getDate("date");
                int target = rs.getInt("target");
                String status = rs.getString("status");
                int locationID = rs.getInt("locationID");
                
                campaigns.add(new Campaign(campaignID, title, date, target, status, supervisorID, locationID));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return campaigns;
    }

    public static boolean createCampaign(int campaignID, String title, Date date, int target, String status, int supervisorID, int locationID) {
    String query = String.format(
        "INSERT INTO campaigns (campaignID, title, date, target, status, supervisorID, locationID) " +
        "VALUES (%d, '%s', '%s', %d, '%s', %d, %d)",
        campaignID, title, new java.sql.Date(date.getTime()), target, status, supervisorID, locationID
    );
    int result = DatabaseConnection.executeUpdate(query);
    return result > 0;
}
}
