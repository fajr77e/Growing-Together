/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject12.service;

/**
 *
 * @author uuiui
 */


import com.mycompany.mavenproject12.model.Tree;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TreeService {
    
    // Plant new tree


public static boolean plantTree(int treeID, String treeType, int quantity, int plantedBy, int campaignID, int locationID) {
    String query = String.format(
        "INSERT INTO trees (treeID, treeType, quantity, plantedBy, campaignID, locationID) " +
        "VALUES (%d, '%s', %d, %d, %d, %d)",
        treeID, treeType, quantity, plantedBy, campaignID, locationID
    );
    int result = DatabaseConnection.executeUpdate(query);
    return result > 0;
}
    
    // Get all trees
    public static List<Tree> getAllTrees() {
        List<Tree> trees = new ArrayList<>();
        String query = "SELECT * FROM trees";
        
        try (ResultSet rs = DatabaseConnection.executeQuery(query)) {
            while (rs != null && rs.next()) {
                int treeID = rs.getInt("treeID");
                String treeType = rs.getString("treeType");
                int quantity = rs.getInt("quantity");
                int plantedBy = rs.getInt("plantedBy");
                int campaignID = rs.getInt("campaignID");
                int locationID = rs.getInt("locationID");
                
                trees.add(new Tree(treeID, treeType, quantity, plantedBy, campaignID, locationID));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return trees;
    }
    
    // Get trees by campaign
    public static List<Tree> getTreesByCampaign(int campaignID) {
        List<Tree> trees = new ArrayList<>();
        String query = String.format("SELECT * FROM trees WHERE campaignID = %d", campaignID);
        
        try (ResultSet rs = DatabaseConnection.executeQuery(query)) {
            while (rs != null && rs.next()) {
                int treeID = rs.getInt("treeID");
                String treeType = rs.getString("treeType");
                int quantity = rs.getInt("quantity");
                int plantedBy = rs.getInt("plantedBy");
                int locationID = rs.getInt("locationID");
                
                trees.add(new Tree(treeID, treeType, quantity, plantedBy, campaignID, locationID));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return trees;
    }
    
    // Get trees by volunteer
    public static List<Tree> getTreesByVolunteer(int volunteerID) {
        List<Tree> trees = new ArrayList<>();
        String query = String.format("SELECT * FROM trees WHERE plantedBy = %d", volunteerID);
        
        try (ResultSet rs = DatabaseConnection.executeQuery(query)) {
            while (rs != null && rs.next()) {
                int treeID = rs.getInt("treeID");
                String treeType = rs.getString("treeType");
                int quantity = rs.getInt("quantity");
                int campaignID = rs.getInt("campaignID");
                int locationID = rs.getInt("locationID");
                
                trees.add(new Tree(treeID, treeType, quantity, volunteerID, campaignID, locationID));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return trees;
    }
    
    // Get trees by location
    public static List<Tree> getTreesByLocation(int locationID) {
        List<Tree> trees = new ArrayList<>();
        String query = String.format("SELECT * FROM trees WHERE locationID = %d", locationID);
        
        try (ResultSet rs = DatabaseConnection.executeQuery(query)) {
            while (rs != null && rs.next()) {
                int treeID = rs.getInt("treeID");
                String treeType = rs.getString("treeType");
                int quantity = rs.getInt("quantity");
                int plantedBy = rs.getInt("plantedBy");
                int campaignID = rs.getInt("campaignID");
                
                trees.add(new Tree(treeID, treeType, quantity, plantedBy, campaignID, locationID));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return trees;
    }
    
    // Update tree quantity
    public static boolean updateTreeQuantity(int treeID, int quantity) {
        String query = String.format(
            "UPDATE trees SET quantity = %d WHERE treeID = %d",
            quantity, treeID
        );
        
        int result = DatabaseConnection.executeUpdate(query);
        return result > 0;
    }
    
    // Delete tree
    public static boolean deleteTree(int treeID) {
        String query = String.format("DELETE FROM trees WHERE treeID = %d", treeID);
        int result = DatabaseConnection.executeUpdate(query);
        return result > 0;
    }
    
    // Get total trees planted by volunteer
    public static int getTotalTreesByVolunteer(int volunteerID) {
        String query = String.format("SELECT SUM(quantity) as total FROM trees WHERE plantedBy = %d", volunteerID);
        
        try (ResultSet rs = DatabaseConnection.executeQuery(query)) {
            if (rs != null && rs.next()) {
                return rs.getInt("total");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return 0;
    }
    
    // Get total trees in campaign
    public static int getTotalTreesInCampaign(int campaignID) {
        String query = String.format("SELECT SUM(quantity) as total FROM trees WHERE campaignID = %d", campaignID);
        
        try (ResultSet rs = DatabaseConnection.executeQuery(query)) {
            if (rs != null && rs.next()) {
                return rs.getInt("total");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return 0;
    }
}
