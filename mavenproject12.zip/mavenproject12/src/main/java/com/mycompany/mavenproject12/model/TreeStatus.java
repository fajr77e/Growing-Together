/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package  com.mycompany.mavenproject12.model;

/**
 *
 * @author uuiui
 */

import java.util.Date;

public class TreeStatus {
    private int logID;
    private int treeID;
    private int reportedBy;    // UserID المبلغ
    private Date reportedDate;
    private String healthStatus;  // "Healthy", "Not Watered", "Dead"
    
    // Constructor كامل
    public TreeStatus(int logID, int treeID, int reportedBy, Date reportedDate, String healthStatus) {
        this.logID = logID;
        this.treeID = treeID;
        this.reportedBy = reportedBy;
        this.reportedDate = reportedDate;
        this.healthStatus = healthStatus;
    }
    
    // Constructor بدون ID
    public TreeStatus(int treeID, int reportedBy, Date reportedDate, String healthStatus) {
        this.treeID = treeID;
        this.reportedBy = reportedBy;
        this.reportedDate = reportedDate;
        this.healthStatus = healthStatus;
    }
    
    // Getters and Setters
    public int getLogID() { return logID; }
    public void setLogID(int logID) { this.logID = logID; }
    
    public int getTreeID() { return treeID; }
    public void setTreeID(int treeID) { this.treeID = treeID; }
    
    public int getReportedBy() { return reportedBy; }
    public void setReportedBy(int reportedBy) { this.reportedBy = reportedBy; }
    
    public Date getReportedDate() { return reportedDate; }
    public void setReportedDate(Date reportedDate) { this.reportedDate = reportedDate; }
    
    public String getHealthStatus() { return healthStatus; }
    public void setHealthStatus(String healthStatus) { this.healthStatus = healthStatus; }
    
    @Override
    public String toString() {
        return healthStatus + " on " + reportedDate;
    }
}
