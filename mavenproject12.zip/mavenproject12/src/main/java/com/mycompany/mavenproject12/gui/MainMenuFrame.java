/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject12.gui;

/**
 *
 * @author uuiui
 */

import com.mycompany.mavenproject12.model.Admin;
import com.mycompany.mavenproject12.model.Volunteer;
import javax.swing.*;
import java.awt.*;

public class MainMenuFrame extends JFrame {
    
    private Admin admin;
    private Volunteer volunteer;
    private boolean isAdmin;
    
    private final Color LINEN = new Color(238, 231, 221);
    private final Color MOSS_GREEN = new Color(146, 148, 51);
    
    // Constructor for Admin
    public MainMenuFrame(Admin admin) {
        this.admin = admin;
        this.isAdmin = true;
        initComponents();
        setTitle("Tree Campaign System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 450);
        setLocationRelativeTo(null);
        setResizable(false);
    }
    
    // Constructor for Volunteer
    public MainMenuFrame(Volunteer volunteer) {
        this.volunteer = volunteer;
        this.isAdmin = false;
        initComponents();
        setTitle("Green Tree Community");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 450);
        setLocationRelativeTo(null);
        setResizable(false);
    }
    
    private void initComponents() {
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(LINEN);
        mainPanel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
        
        // Title
        JPanel titlePanel = new JPanel();
        titlePanel.setBackground(LINEN);
        JLabel titleLabel = new JLabel("Green Tree Community");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        titleLabel.setForeground(MOSS_GREEN);
        titlePanel.add(titleLabel);
        mainPanel.add(titlePanel, BorderLayout.NORTH);
        
        // Welcome Label
        JPanel welcomePanel = new JPanel();
        welcomePanel.setBackground(LINEN);
            String fullName = isAdmin ? admin.getFullName() : volunteer.getFullName();
             String role = isAdmin ? "Admin" : "Volunteer";
           JLabel welcomeLabel = new JLabel(role + ": " + fullName);
       
        welcomeLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        welcomeLabel.setForeground(new Color(100, 100, 100));
        welcomePanel.add(welcomeLabel);
        mainPanel.add(welcomePanel, BorderLayout.CENTER);
        
        // Buttons Panel
        JPanel buttonsPanel = new JPanel(new GridLayout(2, 2, 20, 20));
        buttonsPanel.setBackground(LINEN);
        buttonsPanel.setBorder(BorderFactory.createEmptyBorder(30, 20, 20, 20));
        
        JButton campaignsBtn = createMenuButton("View Campaigns");
        JButton treesBtn = createMenuButton("View Trees");
        JButton locationsBtn = createMenuButton("View Locations");
        JButton logoutBtn = createMenuButton("Logout");
        
        campaignsBtn.addActionListener(e -> openCampaignsView());
        treesBtn.addActionListener(e -> openTreesView());
        locationsBtn.addActionListener(e -> openLocationsView());
        logoutBtn.addActionListener(e -> logout());
        
        buttonsPanel.add(campaignsBtn);
        buttonsPanel.add(treesBtn);
        buttonsPanel.add(locationsBtn);
        buttonsPanel.add(logoutBtn);
        
        mainPanel.add(buttonsPanel, BorderLayout.SOUTH);
        
        add(mainPanel);
    }
    
    private JButton createMenuButton(String text) {
        JButton button = new JButton(text);
        button.setBackground(MOSS_GREEN);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setPreferredSize(new Dimension(180, 50));
        return button;
    }
    
    private void openCampaignsView() {
        if (isAdmin) {
            new AdminCampaignsView(admin).setVisible(true);
        } else {
            new VolunteerCampaignsView(volunteer).setVisible(true);
        }
        dispose();
    }
    
    private void openTreesView() {
        if (isAdmin) {
            new AdminTreesView(admin).setVisible(true);
        } else {
            new VolunteerTreesView(volunteer).setVisible(true);
        }
        dispose();
    }
    
    private void openLocationsView() {
        if (isAdmin) {
            new AdminLocationsView(admin).setVisible(true);
        } else {
            new VolunteerLocationsView(volunteer).setVisible(true);
        }
        dispose();
    }
    
    private void logout() {
        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to logout?", "Logout", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            new LoginForm().setVisible(true);
            dispose();
        }
    }
}