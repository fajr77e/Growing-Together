/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject12.model;

/**
 *
 * @author uuiui
 */
public class VolunteerSkill {
    private int skillID;
    private int userID;
    private String skill;
    
    public VolunteerSkill(int skillID, int userID, String skill) {
        this.skillID = skillID;
        this.userID = userID;
        this.skill = skill;
    }
    
    // Getters and Setters
    public int getSkillID() { return skillID; }
    public void setSkillID(int skillID) { this.skillID = skillID; }
    
    public int getUserID() { return userID; }
    public void setUserID(int userID) { this.userID = userID; }
    
    public String getSkill() { return skill; }
    public void setSkill(String skill) { this.skill = skill; }
}
