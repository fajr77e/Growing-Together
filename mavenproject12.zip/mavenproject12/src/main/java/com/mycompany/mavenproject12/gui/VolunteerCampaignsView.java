/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject12.gui;

/**
 *
 * @author uuiui
 */

import com.mycompany.mavenproject12.model.Volunteer;
import com.mycompany.mavenproject12.model.Campaign;
import com.mycompany.mavenproject12.service.CampaignService;
import com.mycompany.mavenproject12.service.VolunteerRegistrationService;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.List;

public class VolunteerCampaignsView extends JFrame {
    
    private Volunteer volunteer;
    private JTable table;
    private DefaultTableModel model;
    
    private final Color TEA_ROSE = new Color(235, 180, 178);
    private final Color LINEN = new Color(238, 231, 221);
    private final Color MATCHA = new Color(215, 215, 153);
    private final Color MOSS_GREEN = new Color(146, 148, 51);
    
    public VolunteerCampaignsView(Volunteer volunteer) {
        this.volunteer = volunteer;
        initComponents();
        setTitle("View Campaigns");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1100, 600);
        setLocationRelativeTo(null);
        loadCampaigns();
    }
    
    private void initComponents() {
        setLayout(new BorderLayout());
        getContentPane().setBackground(LINEN);
        
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        topPanel.setBackground(LINEN);
        topPanel.setBorder(new EmptyBorder(10, 10, 5, 10));
        
        JButton backBtn = new JButton("Back to Main Menu");
        backBtn.setBackground(MOSS_GREEN);
        backBtn.setForeground(Color.WHITE);
        backBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        backBtn.setFocusPainted(false);
        backBtn.setBorderPainted(false);
        backBtn.addActionListener(e -> goBack());
        topPanel.add(backBtn);
        
        add(topPanel, BorderLayout.NORTH);
        
        JLabel titleLabel = new JLabel("View Campaigns");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 22));
        titleLabel.setForeground(MOSS_GREEN);
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        titleLabel.setBorder(new EmptyBorder(10, 0, 15, 0));
        add(titleLabel, BorderLayout.CENTER);
        
        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.setBackground(LINEN);
        tablePanel.setBorder(new EmptyBorder(10, 20, 10, 20));
        
        String[] columns = {"ID", "Title", "Date", "Goal", "Status", "Location ID"};
        model = new DefaultTableModel(columns, 0);
        table = new JTable(model);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setRowHeight(30);
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        table.getTableHeader().setBackground(MATCHA);
        table.setSelectionBackground(Color.BLUE);
        
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createLineBorder(MATCHA, 1));
        tablePanel.add(scrollPane, BorderLayout.CENTER);
        
        add(tablePanel, BorderLayout.CENTER);
        
        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 15));
        actionPanel.setBackground(LINEN);
        actionPanel.setBorder(new EmptyBorder(5, 0, 20, 0));
        
        JButton registerBtn = createActionButton("Register for Campaign");
        JButton viewTreesBtn = createActionButton("View Trees in Campaign");
        
        registerBtn.addActionListener(e -> registerForCampaign());
        viewTreesBtn.addActionListener(e -> showTreesByCampaign());
        
        actionPanel.add(registerBtn);
        actionPanel.add(viewTreesBtn);
        
        add(actionPanel, BorderLayout.SOUTH);
    }
    
    private JButton createActionButton(String text) {
        JButton button = new JButton(text);
        button.setBackground(MOSS_GREEN);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Segoe UI", Font.BOLD, 13));
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setPreferredSize(new Dimension(200, 40));
        return button;
    }
    
    private void loadCampaigns() {
        model.setRowCount(0);
        List<Campaign> campaigns = CampaignService.getAllCampaigns();
        for (Campaign c : campaigns) {
            model.addRow(new Object[]{
                c.getCampaignID(), c.getTitle(), c.getDate(), 
                "Plant " + c.getTarget() + " trees", c.getStatus(), c.getLocationID()
            });
        }
    }
    
    private void registerForCampaign() {
        int row = table.getSelectedRow();
        if (row >= 0) {
            int campaignID = (int) table.getValueAt(row, 0);
            String campaignTitle = (String) table.getValueAt(row, 1);
            
            boolean alreadyRegistered = VolunteerRegistrationService.isAlreadyRegistered(campaignID, volunteer.getUserID());
            if (alreadyRegistered) {
                JOptionPane.showMessageDialog(this, "You are already registered for this campaign!");
            } else {
                int confirm = JOptionPane.showConfirmDialog(this, "Register for campaign: " + campaignTitle + "?", "Confirm", JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    boolean success = VolunteerRegistrationService.registerToCampaign(campaignID, volunteer.getUserID());
                    JOptionPane.showMessageDialog(this, success ? "Registered successfully!" : "Registration failed!");
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select a campaign first!");
        }
    }
    
    private void showTreesByCampaign() {
        int row = table.getSelectedRow();
        if (row >= 0) {
            int campaignID = (int) table.getValueAt(row, 0);
            String campaignTitle = (String) table.getValueAt(row, 1);
            new VolunteerTreesByCampaignView(volunteer, campaignID, campaignTitle).setVisible(true);
            dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Please select a campaign first!");
        }
    }
    
    private void goBack() {
        new MainMenuFrame(volunteer).setVisible(true);
        dispose();
    }
}
