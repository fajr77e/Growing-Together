/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package  com.mycompany.mavenproject12.model;

/**
 *
 * @author uuiui
 */

import java.util.Date;

public class Campaign {
    private int campaignID;
    private String title;
    private Date date;
    private int target;      // الهدف (عدد الأشجار)
    private String status;   // "Active", "Completed", "Cancelled"
    private int supervisorID;
    private int locationID;
    
    // Constructor كامل
    public Campaign(int campaignID, String title, Date date, int target, String status, int supervisorID, int locationID) {
        this.campaignID = campaignID;
        this.title = title;
        this.date = date;
        this.target = target;
        this.status = status;
        this.supervisorID = supervisorID;
        this.locationID = locationID;
    }
    
    // Constructor بدون ID (للإضافة الجديدة)
    public Campaign(String title, Date date, int target, String status, int supervisorID, int locationID) {
        this.title = title;
        this.date = date;
        this.target = target;
        this.status = status;
        this.supervisorID = supervisorID;
        this.locationID = locationID;
    }
    
    // Getters and Setters
    public int getCampaignID() { return campaignID; }
    public void setCampaignID(int campaignID) { this.campaignID = campaignID; }
    
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    
    public Date getDate() { return date; }
    public void setDate(Date date) { this.date = date; }
    
    public int getTarget() { return target; }
    public void setTarget(int target) { this.target = target; }
    
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    
    public int getSupervisorID() { return supervisorID; }
    public void setSupervisorID(int supervisorID) { this.supervisorID = supervisorID; }
    
    public int getLocationID() { return locationID; }
    public void setLocationID(int locationID) { this.locationID = locationID; }
    
    @Override
    public String toString() {
        return title + " (" + status + ")";
    }
}
