/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject12.service;

/**
 *
 * @author uuiui
 */


import com.mycompany.mavenproject12.model.TreeStatus;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class TreeStatusService {
    
    // Report tree status
  
public static boolean reportTreeStatus(int treeID, int reportedBy, String healthStatus) {
    // الحصول على أكبر logID موجود + 1
    String maxQuery = "SELECT IFNULL(MAX(logID), 0) + 1 AS nextId FROM tree_status";
    int nextId = 1;
    try (ResultSet rs = DatabaseConnection.executeQuery(maxQuery)) {
        if (rs != null && rs.next()) {
            nextId = rs.getInt("nextId");
        }
    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    }

    String query = String.format(
        "INSERT INTO tree_status (logID, treeID, reportedBy, reportedDate, healthStatus) " +
        "VALUES (%d, %d, %d, CURDATE(), '%s')",
        nextId, treeID, reportedBy, healthStatus
    );
    int result = DatabaseConnection.executeUpdate(query);
    return result > 0;
}

public static String getLatestTreeStatus(int treeID) {
    String query = "SELECT healthStatus FROM tree_status WHERE treeID = " + treeID + " ORDER BY reportedDate DESC LIMIT 1";
    try (ResultSet rs = DatabaseConnection.executeQuery(query)) {
        if (rs != null && rs.next()) return rs.getString("healthStatus");
    } catch (SQLException e) { e.printStackTrace(); }
    return null;
}
    
    // Get all tree status reports
    public static List<TreeStatus> getAllTreeStatusReports() {
        List<TreeStatus> reports = new ArrayList<>();
        String query = "SELECT * FROM tree_status ORDER BY reportedDate DESC";
        
        try (ResultSet rs = DatabaseConnection.executeQuery(query)) {
            while (rs != null && rs.next()) {
                int logID = rs.getInt("logID");
                int treeID = rs.getInt("treeID");
                int reportedBy = rs.getInt("reportedBy");
                Date reportedDate = rs.getTimestamp("reportedDate");
                String healthStatus = rs.getString("healthStatus");
                
                reports.add(new TreeStatus(logID, treeID, reportedBy, reportedDate, healthStatus));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return reports;
    }
    
    // Get latest status for a tree

    
    // Get all trees with specific health status
    public static List<Integer> getTreesByHealthStatus(String healthStatus) {
        List<Integer> treeIDs = new ArrayList<>();
        String query = String.format(
            "SELECT DISTINCT treeID FROM tree_status WHERE healthStatus = '%s'",
            healthStatus
        );
        
        try (ResultSet rs = DatabaseConnection.executeQuery(query)) {
            while (rs != null && rs.next()) {
                treeIDs.add(rs.getInt("treeID"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return treeIDs;
    }
    
    // Get unhealthy trees (Not Watered or Dead)
    public static List<Integer> getUnhealthyTrees() {
        List<Integer> treeIDs = new ArrayList<>();
        String query = "SELECT DISTINCT treeID FROM tree_status WHERE healthStatus IN ('Not Watered', 'Dead')";
        
        try (ResultSet rs = DatabaseConnection.executeQuery(query)) {
            while (rs != null && rs.next()) {
                treeIDs.add(rs.getInt("treeID"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return treeIDs;
    }
    
    // Get reports by volunteer
    public static List<TreeStatus> getReportsByVolunteer(int volunteerID) {
        List<TreeStatus> reports = new ArrayList<>();
        String query = String.format("SELECT * FROM tree_status WHERE reportedBy = %d ORDER BY reportedDate DESC", volunteerID);
        
        try (ResultSet rs = DatabaseConnection.executeQuery(query)) {
            while (rs != null && rs.next()) {
                int logID = rs.getInt("logID");
                int treeID = rs.getInt("treeID");
                Date reportedDate = rs.getTimestamp("reportedDate");
                String healthStatus = rs.getString("healthStatus");
                
                reports.add(new TreeStatus(logID, treeID, volunteerID, reportedDate, healthStatus));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return reports;
    }
}
