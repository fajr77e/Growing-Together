/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package  com.mycompany.mavenproject12.model;

/**
 *
 * @author uuiui
 */

public class Volunteer extends User {
    
    public Volunteer(int userID, String firstName, String lastName, String email, String password, String phone) {
        super(userID, firstName, lastName, email, password, phone, "Volunteer");
    }
    
    public Volunteer(String firstName, String lastName, String email, String password, String phone) {
        super(firstName, lastName, email, password, phone, "Volunteer");
    }
}