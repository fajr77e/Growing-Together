/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package  com.mycompany.mavenproject12.model;

/**
 *
 * @author uuiui
 */


public class Location {
    private int locationID;
    private String name;
    private String city;
    
    // Constructor كامل
    public Location(int locationID, String name, String city) {
        this.locationID = locationID;
        this.name = name;
        this.city = city;
    }
    
    // Constructor بدون ID
    public Location(String name, String city) {
        this.name = name;
        this.city = city;
    }
    
    // Getters and Setters
    public int getLocationID() { return locationID; }
    public void setLocationID(int locationID) { this.locationID = locationID; }
    
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    
    public String getCity() { return city; }
    public void setCity(String city) { this.city = city; }
    
    @Override
    public String toString() {
        return name + " - " + city;
    }
}
