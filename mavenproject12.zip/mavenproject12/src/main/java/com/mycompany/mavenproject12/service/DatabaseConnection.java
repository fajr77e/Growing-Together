/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject12.service;

/**
 *
 * @author uuiui
 */


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;

public class DatabaseConnection {
    
    // Database configuration
    private static final String URL = "jdbc:mysql://localhost:3306/greenpath_db";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "System";
    
    private static Connection connection = null;
    
    // Private constructor (Singleton Pattern)
    private DatabaseConnection() {}
    
    // Get single connection instance (Singleton)
    public static Connection getConnection() {
        if (connection == null) {
            try {
                // Load MySQL driver
                Class.forName("com.mysql.cj.jdbc.Driver");
                
                // Create connection
                connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
                System.out.println("Database connected successfully!");
                
            } catch (ClassNotFoundException e) {
                System.err.println(" Error: MySQL driver not found");
                e.printStackTrace();
            } catch (SQLException e) {
                System.err.println(" Database connection error");
                e.printStackTrace();
            }
        }
        return connection;
    }
    
    // Close connection
    public static void closeConnection() {
        if (connection != null) {
            try {
                connection.close();
                connection = null;
                System.out.println("Database connection closed");
            } catch (SQLException e) {
                System.err.println("Error closing connection");
                e.printStackTrace();
            }
        }
    }
    
    // Test connection
    public static boolean testConnection() {
        try {
            Connection conn = getConnection();
            return conn != null && !conn.isClosed();
        } catch (SQLException e) {
            return false;
        }
    }
    
    // Execute UPDATE, INSERT, DELETE queries
    public static int executeUpdate(String query) {
        try (Statement stmt = getConnection().createStatement()) {
            return stmt.executeUpdate(query);
        } catch (SQLException e) {
            System.err.println("Error executing query: " + query);
            e.printStackTrace();
            return -1;
        }
    }
    
    // Execute SELECT queries
    public static ResultSet executeQuery(String query) {
        try {
            Statement stmt = getConnection().createStatement();
            return stmt.executeQuery(query);
        } catch (SQLException e) {
            System.err.println("Error fetching data");
            e.printStackTrace();
            return null;
        }
    }
}
