/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject12.service;

/**
 *
 * @author uuiui
 */

import com.mycompany.mavenproject12.model.VolunteerRegistration;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class VolunteerRegistrationService {
    
    // Register volunteer to campaign
    public static boolean registerToCampaign(int campaignID, int volunteerID) {
        // Check if already registered
        if (isAlreadyRegistered(campaignID, volunteerID)) {
            System.err.println("Volunteer already registered for this campaign");
            return false;
        }
        
        String query = String.format(
            "INSERT INTO volunteer_registrations (campaignID, volunteerID, registeredAt) VALUES (%d, %d, '%s')",
            campaignID, volunteerID, new java.sql.Timestamp(new Date().getTime())
        );
        
        int result = DatabaseConnection.executeUpdate(query);
        return result > 0;
    }
    
    // Check if already registered
    public static boolean isAlreadyRegistered(int campaignID, int volunteerID) {
        String query = String.format(
            "SELECT * FROM volunteer_registrations WHERE campaignID = %d AND volunteerID = %d",
            campaignID, volunteerID
        );
        
        try (ResultSet rs = DatabaseConnection.executeQuery(query)) {
            return rs != null && rs.next();
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    // Get all registrations
    public static List<VolunteerRegistration> getAllRegistrations() {
        List<VolunteerRegistration> registrations = new ArrayList<>();
        String query = "SELECT * FROM volunteer_registrations";
        
        try (ResultSet rs = DatabaseConnection.executeQuery(query)) {
            while (rs != null && rs.next()) {
                int registrationID = rs.getInt("registrationID");
                int campaignID = rs.getInt("campaignID");
                int volunteerID = rs.getInt("volunteerID");
                Date registeredAt = rs.getTimestamp("registeredAt");
                
                registrations.add(new VolunteerRegistration(registrationID, campaignID, volunteerID, registeredAt));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return registrations;
    }
    
    // Get volunteers by campaign
    public static List<Integer> getVolunteersByCampaign(int campaignID) {
        List<Integer> volunteers = new ArrayList<>();
        String query = String.format("SELECT volunteerID FROM volunteer_registrations WHERE campaignID = %d", campaignID);
        
        try (ResultSet rs = DatabaseConnection.executeQuery(query)) {
            while (rs != null && rs.next()) {
                volunteers.add(rs.getInt("volunteerID"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return volunteers;
    }
    
    // Get campaigns by volunteer
    public static List<Integer> getCampaignsByVolunteer(int volunteerID) {
        List<Integer> campaigns = new ArrayList<>();
        String query = String.format("SELECT campaignID FROM volunteer_registrations WHERE volunteerID = %d", volunteerID);
        
        try (ResultSet rs = DatabaseConnection.executeQuery(query)) {
            while (rs != null && rs.next()) {
                campaigns.add(rs.getInt("campaignID"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return campaigns;
    }
    
    // Unregister from campaign
    public static boolean unregisterFromCampaign(int campaignID, int volunteerID) {
        String query = String.format(
            "DELETE FROM volunteer_registrations WHERE campaignID = %d AND volunteerID = %d",
            campaignID, volunteerID
        );
        
        int result = DatabaseConnection.executeUpdate(query);
        return result > 0;
    }
    
    // Get registration count for campaign
    public static int getRegistrationCount(int campaignID) {
        String query = String.format("SELECT COUNT(*) as count FROM volunteer_registrations WHERE campaignID = %d", campaignID);
        
        try (ResultSet rs = DatabaseConnection.executeQuery(query)) {
            if (rs != null && rs.next()) {
                return rs.getInt("count");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return 0;
    }
}
