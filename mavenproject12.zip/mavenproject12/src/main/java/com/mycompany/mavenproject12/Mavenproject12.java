/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject12;

/**
 *
 * @author uuiui
 */

import com.mycompany.mavenproject12.gui.LoginForm;
import com.mycompany.mavenproject12.service.DatabaseConnection;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

public class Mavenproject12 {
    
    public static void main(String[] args) {
        // Test database connection
        if (DatabaseConnection.testConnection()) {
            SwingUtilities.invokeLater(() -> {
                new LoginForm().setVisible(true);
            });
        } else {
            JOptionPane.showMessageDialog(null, 
                "Cannot connect to database!\nPlease check:\n1. MySQL is running\n2. Database 'greenpath_db' exists\n3. Username/password are correct", 
                "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}