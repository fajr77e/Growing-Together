package com.mycompany.mavenproject12.gui;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author uuiui
 */




import com.mycompany.mavenproject12.model.User;
import com.mycompany.mavenproject12.model.Admin;
import com.mycompany.mavenproject12.model.Volunteer;
import com.mycompany.mavenproject12.service.UserService;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LoginForm extends JFrame {
    
    private JTextField emailField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private JButton registerButton;
    
    // Colors from palette
    private final Color TEA_ROSE = new Color(235, 180, 178);
    private final Color LINEN = new Color(238, 231, 221);
    private final Color MATCHA = new Color(215, 215, 153);
    private final Color MOSS_GREEN = new Color(146, 148, 51);
    
    public LoginForm() {
        initComponents();
        setTitle("Green Community Tree - Login");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(450, 400);
        setLocationRelativeTo(null);
        setResizable(false);
    }
    
    private void initComponents() {
        // Main panel with Linen background
        JPanel mainPanel = new JPanel(new GridBagLayout());
        mainPanel.setBackground(LINEN);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(15, 15, 15, 15);
        
        // Title Label
        JLabel titleLabel = new JLabel("Green Tree Community");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 32));
        titleLabel.setForeground(MOSS_GREEN);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        mainPanel.add(titleLabel, gbc);
        
        // Subtitle
        JLabel subtitleLabel = new JLabel("Login to your account");
        subtitleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        subtitleLabel.setForeground(new Color(100, 100, 100));
        gbc.gridy = 1;
        mainPanel.add(subtitleLabel, gbc);
        
        // Email Label
        gbc.gridwidth = 1;
        gbc.gridy = 2;
        gbc.gridx = 0;
        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        emailLabel.setForeground(MOSS_GREEN);
        mainPanel.add(emailLabel, gbc);
        
        // Email Field
        gbc.gridx = 1;
        emailField = new JTextField(15);
        emailField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        emailField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(MATCHA, 1),
            BorderFactory.createEmptyBorder(8, 8, 8, 8)
        ));
        mainPanel.add(emailField, gbc);
        
        // Password Label
        gbc.gridx = 0;
        gbc.gridy = 3;
        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        passwordLabel.setForeground(MOSS_GREEN);
        mainPanel.add(passwordLabel, gbc);
        
        // Password Field
        gbc.gridx = 1;
        passwordField = new JPasswordField(15);
        passwordField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        passwordField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(MATCHA, 1),
            BorderFactory.createEmptyBorder(8, 8, 8, 8)
        ));
        mainPanel.add(passwordField, gbc);
        
        // Button Panel
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 0));
        buttonPanel.setBackground(LINEN);
        
        // Login Button
        loginButton = new JButton("Login");
        loginButton.setBackground(MOSS_GREEN);
        loginButton.setForeground(Color.WHITE);
        loginButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        loginButton.setFocusPainted(false);
        loginButton.setBorderPainted(false);
        loginButton.setPreferredSize(new Dimension(100, 40));
        loginButton.addActionListener(new LoginAction());
        
        // Register Button
        registerButton = new JButton("New User? Register");
        registerButton.setBackground(MOSS_GREEN);
        registerButton.setForeground(Color.WHITE);
        registerButton.setFont(new Font("Segoe UI", Font.BOLD, 12));
        registerButton.setFocusPainted(false);
        registerButton.setBorderPainted(false);
        registerButton.setPreferredSize(new Dimension(150, 40));
        registerButton.addActionListener(e -> openRegisterForm());
        
        buttonPanel.add(loginButton);
        buttonPanel.add(registerButton);
        mainPanel.add(buttonPanel, gbc);
        
        add(mainPanel);
    }
    
    private class LoginAction implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String email = emailField.getText().trim();
            String password = new String(passwordField.getPassword()).trim();
            
            if (email.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(LoginForm.this, 
                    "Please enter email and password!", 
                    "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            User user = UserService.login(email, password);
            
            if (user != null) {
                JOptionPane.showMessageDialog(LoginForm.this, 
                    "Welcome " + user.getName() + "!", 
                    "Success", JOptionPane.INFORMATION_MESSAGE);
                
                if (user instanceof Admin) {
                    openAdminDashboard((Admin) user);
                } else {
                    openVolunteerDashboard((Volunteer) user);
                }
                dispose();
            } else {
                JOptionPane.showMessageDialog(LoginForm.this, 
                    "Invalid email or password!", 
                    "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    private void openRegisterForm() {
        RegisterForm registerForm = new RegisterForm();
        registerForm.setVisible(true);
        dispose();
    }
    
 private void openAdminDashboard(Admin admin) {
    new MainMenuFrame(admin).setVisible(true);
    dispose();
}

private void openVolunteerDashboard(Volunteer volunteer) {
    new MainMenuFrame(volunteer).setVisible(true);
    dispose();
}
}