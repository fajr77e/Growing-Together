/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package  com.mycompany.mavenproject12.model;

/**
 *
 * @author uuiui
 */

public class Tree {
    private int treeID;
    private String treeType;
    private int quantity;
    private int plantedBy;    // UserID المتطوع
    private int campaignID;
    private int locationID;
    
    // Constructor كامل
    public Tree(int treeID, String treeType, int quantity, int plantedBy, int campaignID, int locationID) {
        this.treeID = treeID;
        this.treeType = treeType;
        this.quantity = quantity;
        this.plantedBy = plantedBy;
        this.campaignID = campaignID;
        this.locationID = locationID;
    }
    
    // Constructor بدون ID
    public Tree(String treeType, int quantity, int plantedBy, int campaignID, int locationID) {
        this.treeType = treeType;
        this.quantity = quantity;
        this.plantedBy = plantedBy;
        this.campaignID = campaignID;
        this.locationID = locationID;
    }
    
    // Getters and Setters
    public int getTreeID() { return treeID; }
    public void setTreeID(int treeID) { this.treeID = treeID; }
    
    public String getTreeType() { return treeType; }
    public void setTreeType(String treeType) { this.treeType = treeType; }
    
    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }
    
    public int getPlantedBy() { return plantedBy; }
    public void setPlantedBy(int plantedBy) { this.plantedBy = plantedBy; }
    
    public int getCampaignID() { return campaignID; }
    public void setCampaignID(int campaignID) { this.campaignID = campaignID; }
    
    public int getLocationID() { return locationID; }
    public void setLocationID(int locationID) { this.locationID = locationID; }
    
    @Override
    public String toString() {
        return quantity + " x " + treeType;
    }
}
